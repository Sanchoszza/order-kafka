package com.example.orderstatusservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderStatusServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderStatusServiceApplication.class, args);
	}

}
