package com.example.orderstatusservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderStatusServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
